# Global Operations Console — Integration Handoff

The design contract for porting `Global Operations Console.dc.html` into the real stack. The prototype is the visual
and behavioral spec; this document is the **data contract**. The client-side demo shim in the file is the reference
implementation for every endpoint and worker described below — when a real backend is present, the UI code is
unchanged; only the data source differs.

Accent `#5a6b87` family slate (the file ships a darker observability slate `--accent:#7d93b8`); dark-first; one accent,
green/amber/red reserved for health and level only.

---

## 1. What it is

A read-mostly internal **mission-control** surface on the shared kit (`OhAppShell` sidebar, dark). It shows, live, the
health of the entire AI Done Right system and lets an operator drop work into the ingest pipeline. Ten routed views:

`Overview · Surfaces & Services · Flywheels · Fleet · Usage · Registries · Discovery & Research · Intake · Activity log · Raw logs · Security`

Realtime model: poll on an interval, update the DOM in place (no reload, no blank), count-up + flash changed numbers,
keep ~46 polls of rolling history for sparklines, show `reconnecting` (dim last-known values) on a failed poll and
recover automatically. Never an error page.

---

## 2. `GET /api/ops/status` — the primary contract (consumed every poll)

The UI reads exactly these fields (see `mapPayload()` in the file). A real `scripts/ops_console_service.py` must answer
this shape. Numbers are illustrative.

```json
{
  "serves_truth": false, "projection_only": true,
  "flywheel": {
    "cycle": 9661, "health": "ok", "last_flywheel": "propose",
    "last_summary": "distilled 24 new proposal(s); backlog now 5253",
    "findings_recorded": 45126,
    "loops": [ {"label":"Sweep","last_cycle":9658,"lag":3,"errors":0} ],
    "hubs_recent": [ {"hub":"OpenCompressionHub","last_cycle":9655} ]
  },
  "services": { "total":28, "up":28, "surfaces_total":12, "surfaces_up":12,
    "services": [ {"name":"OpenHubForAI app","port":8000,"up":true,"is_surface":true} ] },
  "registries": { "registries":159, "records":159000, "real":2473, "synthetic":156527, "target_per_registry":1000 },
  "usage": { "total":2295, "by_site":{"openhubforai":436,"aidoneright":1859},
             "by_type":{"page":1355,"exposure":921,"conversion":19} },
  "discovery": { "candidates":636, "quarantined":0, "security_gate":"active (ingest quarantine + promotion block, >= high)" },
  "research": { "proposals_backlog":5253, "findings":45128 },
  "fleet": { "ok":true, "tasks":{"by_status":{"done":120,"running":3,"queued":8}}, "execution":{"total":4210} }
}
```

**Degrade honestly.** `usage` or `fleet` may instead be `{"status":"… offline"}`; the UI renders that panel as offline,
keeps its last values dimmed, and recovers when the field returns. Don't fabricate data.

**Field → view map.** Overview rollup + sparklines: `services.{surfaces_up,up,...}`, `registries`, `research`,
`usage.total`, `flywheel.cycle`. Surfaces grid: `services.services[]` grouped by `is_surface`. Flywheels:
`flywheel.{loops,last_flywheel,last_summary,hubs_recent,findings_recorded}`. Fleet: `fleet.*`. Usage:
`usage.*`. Registries: `registries.*`. Discovery: `discovery.*` + `research.*`. Security: the governance posture +
`serves_truth`.

---

## 3. `POST /api/ops/intake` — NEW endpoint + pipeline workers

The Intake view submits operator-dropped content. Request:

```json
POST /api/ops/intake
{ "content": "<raw text, URL, idea, or prompt>", "kind": "link|prompt|idea|text" }
→ 200 { "accepted": true, "id": "in_ab12cd", "serves_truth": false, "queued": true }
```

The submission is **governed candidate material**: it enters the ingest queue as quarantined, `serves_truth=false`, and
is never promoted to truth without passing the security gate. The console's only write path.

**Worker model the UI visualizes** (implement server-side; the client simulation is the spec):

- **Classify** — detect `kind`: link (URL), prompt (ends with `?` or imperative verb), idea (short non-link), else text.
- **Prioritize** — `high` for urgency keywords (`urgent|asap|critical|important|now|blocker`) or `!!`, else `med` for
  links/prompts/long text, else `low`. High sorts to the top of the queue.
- **Chunk** — links → ~3, prompts → 1, text/idea → `ceil(words / 40)`.
- **Route** — `kind → queue`: link → `fetch` (Fetch & extract), prompt → `prompteval` (Prompt eval), idea → `distill`
  (Proposal distill), text → `chunk` (Chunk & embed).
- **Process** — stages `queued → classifying → chunking → analyzing → done`. The UI advances on the tick; the real
  workers advance as work completes.

To make the queue depths and item stages real on the dashboard, expose them on `/api/ops/status` (e.g. an `intake`
block with per-queue depth and per-item stage), or a dedicated `GET /api/ops/intake`.

---

## 4. `GET /api/ops/logs` — implied by the Raw logs console

The Raw logs view aggregates structured log lines from Docker containers, Kubernetes pods, backend services, and
product surfaces. The demo generates them client-side; a real endpoint should stream/return entries of this shape:

```json
{ "id": 1421, "ts": 1719500000000, "type": "docker|k8s|svc|surface", "label": "observer-runtime",
  "level": "info|warn|error", "msg": "health check passed",
  "json": { "timestamp": "…Z", "level": "info", "source": "docker/observer-runtime", "message": "…",
            "status": 200, "latency_ms": 93, "trace_id": "77934aad", "container|pod|port": "…" } }
```

UI provides: source-type filter (all/surface/svc/docker/k8s), level filter, text search, Live/Pause, and a
click-to-inspect raw-JSON pane. A real implementation would page or tail from the log backend; keep the buffer bounded
(the UI keeps 240).

---

## 5. Realtime + governance requirements

- Poll interval is a prop (`pollSeconds`, default 3). Update in place; never reload or blank.
- Reconnect: on a failed poll show `reconnecting`, dim last-known values, recover on the next success.
- Read-mostly: the only non-GET is `POST /api/ops/intake`. No control actions (no start/stop/kill).
- `serves_truth = false` everywhere; candidate output and intake submissions are projection only.
- BYO keys (if used for a fetch) are used once and never stored.

## 6. Acceptance (parity with the prototype)

- [ ] Within one interval of load, numbers move, the LIVE dot pulses, "updated Ns ago" counts.
- [ ] All ten views render real panels — no blanks, no placeholders.
- [ ] Sparklines draw from rolling history; status dots/badges recolor by health.
- [ ] A failed poll shows reconnecting, keeps dimmed last values, and recovers.
- [ ] Intake: a submission classifies, prioritizes, chunks, routes to the right queue, and advances to done.
- [ ] Raw logs: multi-source filter + level filter + search + JSON inspect all work.
- [ ] Only GET, plus the single governed `POST /api/ops/intake`.

## 7. Porting notes

Each `sc-if` view → a route component; `renderVals()` keys → that component's props/derived state. The demo shim
(`installShim()`) is removed in production — point `fetch` at the real endpoints; everything else is identical. Keep the
one-accent rule and the four-state discipline (live / reconnecting / degraded-offline / empty).
