# AIDevObserver, logged-in app (design)

> Status: living document. The merge instructions are in `INTEGRATION-HANDOFF.md`. No em or en dashes anywhere
> (house rule). serves_truth = false on candidate output.

## What this is

`AIDevObserver.dc.html` is a single Design Component that builds the AIDevObserver product (the marketing home plus the
logged-in app) from the AI Done Right design bible and the AIDevObserver brief. AIDevObserver reviews how a team uses AI
coding agents and turns each session into a clear, ranked report. This is the front-end design, faithful to the shared
house style (accent `#b25fd6`), with believable seeded data shaped like the real `/api/observer/review` payload.

## What is built

The **marketing home** (the public top-nav layout: hero, how-it-works, what-it-flags, a call-to-action band, footer)
plus the **logged-in app** behind the `OhAppShell` left sidebar (grouped Workspace and Account), the sticky account top
bar, the command palette, and the governance framing. The app defaults to Review; reach the marketing home from the
topbar "View site" link or the palette. Screens:

- **Review** (default): the report for the selected session. A summary strip (findings, reinventions, waste signals,
  messages reviewed) and a by-type chip row, then the finding cards ranked by confidence. Empty state for a clean
  session, skeleton while loading.
- **Sessions**: every reviewed session (project, source tool, started, top finding, finding count). Click to open a
  report. Normalized from Claude Code, Cursor, Copilot, and the CLI.
- **Findings**: every finding across sessions as governed candidate objects, filter chips with counts, and the
  Accept / Reuse / Dismiss outcome per row (the signal the engine learns from).
- **Agentic runs**: supervises autonomous agent loops. A runs list with a verdict badge (clean, wasteful, stalled or
  runaway), a runaway advisory (Pause or Dismiss, never a kill), and loop-shape findings (thrash, repeated failure,
  stall, budget overrun, goal drift) in the finding card with a Step N locator.
- **Reports** (leader view): a You / Team / Organization scope switcher over savings, reuse rate, per-developer and
  per-team tables, findings by type, and the most reinvented registry components.
- **Demo**: paste a session as JSON or load the example, then review; the result renders with the same finding card.
  Invalid JSON shows the error state.
- **Members**: seat and role management (invite, role select, remove). Seats grant access; billing is usage-metered.
- **Billing**: the usage-metered plan, this-period meters (sessions, findings, live checks), a usage chart, invoices.
- **Settings**: the mode (silent record, review only, advisory, active, enforcing), the interruption budget, the
  governed BYO-key field, the four install lines, and the internal-registry connect.
- **Account**: profile, security (two-factor, password, active sessions), and notification toggles.

### The finding card (the core component)

Renders the real engine fields: a **type** chip toned by family (accent for the reinvention family, amber for waste,
red for footgun, neutral for adversarial and guidance and alternative), the **confidence** (bar and percent), the
**message**, the **evidence** (monospace; redacted and muted for footgun), the **suggestion**, the **source_ref**
chips (`existing` as a `registry / name` deep-link into OpenHubForAI, or `covering` as a `package` plus what it
provides), an optional **reuse savings** stat, an optional footgun **advisory**, the **Accept / Reuse / Dismiss**
actions, and the `candidate · serves_truth = false` line.

The ten engine types: reinvention, stack_reinvention, product_reinvention, oversized_context, duplicate_context,
shortcut, footgun, adversarial, guidance, alternative.

## Built on the shared kit

Faithful to `.oh.dir-s.theme-light`: warm near-white surfaces, accent `#b25fd6`, Inter for UI, Hanken Grotesk for
display, JetBrains Mono for code, and the `.oh-*` atoms and `OhAppShell` chrome, reproduced as inline styles per the
Design Component model. It does not fork the kit. Light theme (the shipped scope).

## Tweaks (code-only controls)

- **Confidence display**: Bar + percent, Percent only, or Bar only.
- **Show savings**: the reuse dollars and hours stat on and off.
- **Governance**: the preview banner and footer on and off.

## Data model and how to extend

The app is data-driven from `SESSIONS` in the logic class, shaped like the real payload.

- Add a session: `{ id, project, tool, sid, when, messagesReviewed, report: [...] }`.
- Add a finding: `{ type, confidence, message, evidence, suggestion, source_ref?, saving?, advisory? }`. Type maps to a
  tone and a label through `META`; severity tone through `TONE`; family through `FAMILY`.
- Add a screen: add a nav entry (`navWork` or `navAccount`), an `isX` flag in `renderVals`, and an `sc-if` block.
- Wire the backend: replace `SESSIONS` and `runReview` with `fetch('/api/observer/...')`. See `INTEGRATION-HANDOFF.md`.

## Ecosystem integration

AIDevObserver is the measurement and feedback layer of the AI Done Right family: it shows a team what its agent usage
costs, then routes each finding to the tool that solves it. A `reinvention` finding deep-links the existing component
in **OpenHubForAI**; reuse savings come from the economics registry; the Accept and Dismiss outcomes feed the
`agent_behavior` and `agent_qa` registries; recurring patterns become **Teleon** capabilities; wasted context routes to
**Baltor**. Full detail and the merge steps are in `INTEGRATION-HANDOFF.md`.

## Files

- `AIDevObserver.dc.html`: the app (template, logic, tweaks).
- `INTEGRATION-HANDOFF.md`: how to merge into `web/aidevobserver/` without breaking the kit, the seams, or the gate.
- `README.md`: this document.

## The family (this project)

The AIDevObserver app is one of five surfaces. The other four are in this project too, so you can see the one design
law directly: every file uses the **same token block and chrome** and differs **only by its accent and its copy**.
They are cross-linked (open any one, then use the footer or the hub).

- `AI Done Right.dc.html`: the parent hub, the portfolio home that introduces the family. Accent slate `#5a6b87`.
- `Teleon.dc.html`: the purpose-driven runtime. "Define the outcome. We prove the rest." Accent indigo `#6d5ef0`.
- `Baltor.dc.html`: managed, verified, provable context. "It is not the model. It is the context." Accent teal `#0e7c86`.
- `AIDevObserver.dc.html`: this app (plus its marketing home). Accent orchid `#b25fd6`.
- `OpenHubForAI.dc.html`: the open store, with a faceted browse teaser over the 242-record federation. Accent royal
  blue `#3b6fd4`.

The hub and the three other homes are marketing-layout surfaces (top nav, hero, sections, band, footer). AIDevObserver
is the built-out one: marketing home plus the full logged-in app. To swap a surface's look you change one value, the
`--accent`, exactly as the design bible specifies.
