# AIDevObserver, north-star production plan

> How the prototype (`AIDevObserver.dc.html`) becomes a fully working, shipped product. This is the bridge from the
> design source of truth to a running SaaS, following the stack your repo already defines (the showcase serving
> `web/<app>/` over the shared kit, the service-plane behind same-origin seams). Pair with `INTEGRATION-HANDOFF.md`
> (the merge contract) and `docs/DESIGN-BIBLE.md` + `docs/INTEGRATION-BIBLE.md` (the laws). serves_truth = false on
> candidate output; a BYO key is used only for the request, never stored or logged.

## What "fully working production" means here (and what is realistic)

The prototype renders every screen and wires every interaction against seeded data. Production adds the four things a
design file cannot contain: a **build**, a **backend**, **real auth/persistence/billing**, and a **deploy**. None of
those are built in the design environment; they are built in the repo. This plan is the ordered path, with the
prototype as the spec each step implements.

The design law holds end to end: one shared kit, five surfaces, differ only by accent and copy. The prototype already
obeys it (no forked kit, one accent, governed states), so the port is mechanical, not a rewrite.

## Stage 0, lock the prototype as the spec (done / ongoing)

- The prototype is the visual + interaction contract. Every route in it (`dashboard`, `review`, `sessions`,
  `findings`, `agentic`, `reports`, `notifications`, `help`, `demo`, `members`, `billing`, `settings`, `account`,
  `developer`, `auth`, the marketing home) maps to one production route component.
- Keep iterating design here; the prototype stays the source of truth for look, copy, states, and flows.

## Stage 1, the front-end build (the precompiled gap the design bible flags)

Today the showcase serves `web/<app>/` with in-browser Babel (no build step). Production needs a real build:

1. Stand up the app at `web/aidevobserver/` per the design bible section 7.1 boot skeleton: `index.html` +
   `aidevobserver-main.jsx` + `aidevobserver.css`, importing the shared kit from `web/aidevobserver/kit/`
   (`oh-tokens.css`, `oh-components.css`, `oh-site.css`, `oh-site.jsx`, `products.js`). Accent `#b25fd6` set inline.
2. Port each prototype screen to a route, 1:1. Each `sc-if` screen becomes a function returning kit markup:
   `OhAppShell` for the sidebar shell, `OhPageHead` + `OhRollup` + `.oh-card`/`.oh-table` for the body, `OhAuth` for
   the login card, `OhTopBar`/`OhFooter` for the marketing home. The bespoke pieces (the finding card, the agentic
   verdict, the registry browser) move into `aidevobserver.css`, token-built, never forking the kit.
3. Add a real bundler and router for shipping: Vite (or Next) with precompiled JSX, code-split routes (lazy-load the
   heavy screens), and the kit's `useHashRoute`/`navigate` swapped for the router you standardize on. This is the
   "precompiled production build" the design bible lists as the known gap.
4. Keep the byte-for-byte design: the bundler output must render identically to the prototype. The shared kit is the
   only style source.

## Stage 2, the backend (the service-plane, behind seams)

Every screen's data comes from a same-origin seam; the front-end never hardcodes a host (INTEGRATION-BIBLE law 1).

1. **Review engine.** The `/api/observer/*` seam is backed by `observer_runtime` (the real engine in
   `src/teleon/observer`). Wire the prototype's seeded `SESSIONS`/`runReview` to the real endpoints:
   `POST /api/observer/review`, `GET /api/observer/sessions`, `POST /api/observer/live`, `POST /api/observer/agentic`.
   The finding card already renders the real payload shape, so this is a fetch swap.
2. **Capture seam.** The thing that makes sessions real: the VS Code/Cursor extension, the MCP server
   (`scripts/aidevobserver_mcp_server.py`), the CLI, and the PreToolUse hook feed sessions into the engine. These are
   the install lines the prototype already shows; production ships them.
3. **Registry deep-links.** The `source_ref` chips resolve against `/registry/` (the 147-catalog federation), so
   "already exists" links to a live record. The OpenHubForAI browser reads the real `/registry/registries` +
   `/registry/search` instead of the generated 242.
4. **Each new endpoint is a service-plane service plus a seam** (INTEGRATION-BIBLE section 4): build the stdlib HTTP
   service, register its port in `architecture/local_service_registry.json`, add one seam line in
   `scripts/showcase/server.py`, then `fetch('/api/<x>/...')`. Add a `check_<x>_local_service.py --self-test` proof.

## Stage 3, identity, account, and persistence

1. **Auth, real realms, NO single sign-on** (hard lock). The prototype's `OhAuth` flow points at `/api/identity/`
   (`local_auth_service`): signup/login/session per product realm. Add the auth modes the inventory lists
   (reset-token, verify, MFA, accept-invite, logged-out, session-expired) as `OhAuth` modes, never a forked screen.
2. **Persistence.** Members, roles, invites, settings (mode, interruption budget, internal registry), notification
   prefs, and finding outcomes (Accept/Reuse/Dismiss) move from prototype state to the datastore. The outcome signal
   is the product's compounding asset, so persist it first; it also populates the `agent_behavior` and `agent_qa`
   registries.
3. **API keys and BYO key, governed.** The Developer screen's create/reveal-once/revoke calls the real key service
   (mint shows the key once, never stores it). The BYO inference key is used per request and never stored or logged.

## Stage 4, billing and metering (usage-metered, not per-seat)

1. The economic unit is consumption: sessions reviewed, findings surfaced, live checks. The prototype's Billing and
   usage meters reflect that model; wire them to the metering service and a billing provider (plan, usage, invoices,
   payment method, dunning, cancel, reactivate). Seats grant access; they are not the meter.
2. Add the inventory's billing states: within-limit / near-limit / over, past-due banner, proration preview. Numbers
   are owner-set; the prototype designs the structure.

## Stage 5, governance, security, and trust (non-negotiable)

- `serves_truth = false` on every model/agent/candidate output; only deterministic, verified, human-approved records
  assert truth. The prototype's governance banner, footer, and per-finding line carry this; production enforces it
  server-side.
- Read-only over the API; findings are suggestions a person triages, never gates.
- Service-to-service auth is not API keys: user OIDC/session, scoped external keys or OAuth clients, service accounts
  with short-lived scoped tokens, mTLS/SPIFFE or workload identity for internal calls, tenant/object/purpose/data-class
  authorization, and audit receipts for privileged calls (`docs/architecture/service-auth-and-consumption-model.md`).
- BYO keys used for one request, never stored or logged.

## Stage 6, deploy (the same code, local and cloud)

- One showcase service per `OH_PRODUCT`, `OH_BIND_HOST=0.0.0.0`, the platform injects the port; set the
  `OH_SEAM_*_BASE` envs so the seams point at the cloud backends. Each backend service deploys as its own
  container/service. The same front-end code and seam paths run unchanged; only the seam base values differ
  (INTEGRATION-BIBLE section 6; `docs/architecture/fly-deploy-runbook.md`, `surface-deploy.md`).
- Stable domains: `aidevobserver.io` (and the family's `aidoneright.dev`, `teleon.dev`, `baltor.ai`,
  `openhubforai.io`).

## Stage 7, the quality gates (definition of done)

- The proof gate stays green: `PYTHONPATH=. python3 scripts/run_proofs.py`, including the observer self-test and the
  shared-kit checks (you never touch the kit to change one surface).
- Playwright (or equivalent): every route renders real content, every control does something, every form runs
  loading → success/error, every data view has empty/loading/populated/error, zero console errors.
- The design law check: accent + copy are the only per-surface variables; no forked kit, no second CSS system.

## How to execute this from here

This design project produces the prototype and these handoff docs. The production build runs in your repo, where the
services, build, and deploy live. The fastest path: use the "Handoff to Claude Code" flow to take
`AIDevObserver.dc.html` plus `INTEGRATION-HANDOFF.md` and this plan into the repo, then implement stage by stage,
keeping the prototype as the visual contract and the seams as the data contract. I can also keep deepening the
prototype here (more screens, the remaining auth modes, onboarding) so every production route has a finished design to
build against.

## Order of work (recommended)

1. Stand up `web/aidevobserver/` on the real kit, port the App shell + Dashboard/Review/Sessions/Findings/Agentic.
2. Wire `/api/observer/*` (review, sessions, agentic), replacing seeded data; keep the four states.
3. Auth + identity realm (`/api/identity/`) + persistence for outcomes, members, settings.
4. Developer (real keys), then the registry deep-links + the OpenHubForAI live browser.
5. Billing/metering, then the remaining account/team pages.
6. Harden governance + service auth, add the proof + Playwright gates, deploy.
