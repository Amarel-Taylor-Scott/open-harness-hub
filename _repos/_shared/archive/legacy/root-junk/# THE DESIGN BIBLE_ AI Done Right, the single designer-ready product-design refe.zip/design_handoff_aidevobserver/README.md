# Handoff: AIDevObserver (and the AI Done Right family)

## Overview

AIDevObserver reviews how a team uses AI coding agents and turns each session into a clear, ranked report (what was
reinvented, what wasted context, what was risky, where a cheaper path existed). It also supervises autonomous agent
loops. This bundle is the full front-end design of the product: the marketing home, the login, and the complete
logged-in app, plus the four sibling surfaces of the family (AI Done Right, Teleon, Baltor, OpenHubForAI).

## About the design files

The files in this bundle are **design references created as HTML prototypes** (the `.dc.html` files are self-contained
and open directly in a browser). They show the intended look and behavior; they are **not production code to ship
directly**. The task is to **recreate them in the target codebase** using its established stack and patterns. For this
product the target stack is already defined: React 18 apps under `web/<app>/` importing the shared kit
(`oh-tokens.css`, `oh-components.css`, `oh-site.css`, `oh-site.jsx`, `products.js`), served by the showcase, with
backends behind same-origin seams. Two companion docs in this folder are the contract for that:

- `INTEGRATION-HANDOFF.md` — how to merge into `web/aidevobserver/` without forking the kit, wire the seams, keep the
  proof gate green, and the porting map (each prototype piece to its kit class).
- `PRODUCTION-PLAN.md` — the seven-stage north-star path to a fully working, deployed SaaS (build, backend, identity,
  billing, governance, deploy, gates).

## Fidelity

**High-fidelity.** Final colors, typography, spacing, states, and interactions. Recreate the UI faithfully using the
codebase's shared kit (the `.oh-*` atoms and `Oh*` components). The one design law: every surface composes the same
kit and differs ONLY by its accent and its copy. Do not fork the kit or add a second CSS system.

## The surfaces (5 files, one shared kit)

Each surface is ONE self-contained, hash-routed app file. Differ only by accent + copy.

| File | Surface | Accent | What it is |
|---|---|---|---|
| `AIDevObserver.dc.html` | AIDevObserver | `#b25fd6` orchid | The built-out product: marketing home + login + full logged-in app |
| `AI Done Right.dc.html` | AI Done Right | `#5a6b87` slate | The parent hub / portfolio home introducing the family |
| `Teleon.dc.html` | Teleon | `#6d5ef0` indigo | Marketing home, the purpose-driven runtime |
| `Baltor.dc.html` | Baltor | `#0e7c86` teal | Marketing home, governed context |
| `OpenHubForAI.dc.html` | OpenHubForAI | `#3b6fd4` royal blue | Marketing home + the faceted registry browser |

## Screens / views (AIDevObserver, hash-routed in one app)

Each is a route in `AIDevObserver.dc.html`. Layout is the shared shell: a 248px left sidebar (`OhAppShell`) plus a
content area that opens with a page head (`OhPageHead`: uppercase accent eyebrow, 30px display title, muted sub), often
a rollup of stat cards, then `.oh-card` content. Marketing and login use different chrome (top nav / centered card).

- **Marketing home** (`home`): top nav (logo, How it works / Pricing / Trust, theme toggle, Sign in, Start free),
  two-column hero (eyebrow, tinted H1, lede, CTAs, a live finding-card aside), how-it-works 3-up, what-it-flags grid,
  CTA band, footer with a Family column linking the other surfaces.
- **Login / Sign up** (`auth`): centered `OhAuth` card (logo, Welcome back / Create account, work email + password,
  Forgot, the "separate realm per product, no single sign-on" governance line, switch sign-in/up, back to site).
- **Dashboard** (`dashboard`, default): rollup (sessions, findings, savings, reuse rate), recent reviews (clickable
  rows), quick-start cards.
- **Review** (`review`): session summary strip + by-type chips, then finding cards ranked by confidence. Empty (clean
  session) and loading (skeleton) states.
- **The finding card** (the core component): a type chip toned by family (accent for reinvention, amber for waste, red
  for footgun with redacted evidence, neutral for adversarial/guidance/alternative), confidence bar + percent, the
  message, monospace evidence, the suggestion, `source_ref` chips (registry deep-link or covering package), optional
  reuse savings, and Accept / Reuse / Dismiss (the outcome), with a `candidate · serves_truth = false` line.
- **Sessions** (`sessions`): table (project, source tool, started, top finding, count), click a row to open Review.
- **Findings** (`findings`): cross-session table, filter chips with counts, outcome column.
- **Agentic runs** (`agentic`): supervises autonomous loops; runs list with verdict badges (clean / wasteful /
  stalled-or-runaway), a runaway advisory (Pause / Dismiss, never a kill), loop-shape findings with a Step N locator.
- **Reports** (`reports`): You / Team / Organization scope switcher over savings, reuse, per-developer and per-team
  tables, findings by type, most-reinvented components.
- **Demo** (`demo`): paste a session (or load the example), review, render the same finding cards; invalid JSON shows
  the error state.
- **Notifications** (`notifications`): list with unread dots, Mark all read.
- **Help** (`help`): support links + the install/MCP/CLI/hook lines.
- **Members** (`members`): seat/role management (invite, role select, remove); seats grant access, billing is metered.
- **Billing** (`billing`): usage-metered plan, this-period meters, a usage chart, invoices.
- **Settings** (`settings`): mode (silent record / review only / advisory / active / enforcing), interruption budget,
  governed BYO-key field, the four install lines, internal-registry connect.
- **Account** (`account`): profile, security (2FA, password, active sessions), notification prefs.
- **Developer** (`developer`): API keys (create with one-time reveal, revoke), webhooks, the `/api/observer/*` endpoint
  reference with method badges, and the MCP/extension/CLI/hook connect lines.
- **Command palette** (⌘K): grouped go-to + actions, keyboard nav.
- **OpenHubForAI registry browser** (in `OpenHubForAI.dc.html`): a facet rail (category, status, layer, kind) with
  live counts, search, sortable table, honest live/partial/gap badges, empty state, over 242 records.

## Interactions & behavior

- Sidebar nav swaps the route; the active item fills with `--accent-weak` and colors `--accent`.
- Finding triage (Accept/Reuse/Dismiss) toggles the outcome and reflects it on Findings.
- Demo and Review run loading → result; the demo parses JSON and shows an error state on bad input.
- Key create reveals the secret once; revoke removes it. Member invite/remove and role change update the table.
- Not-yet-wired actions (Export, Connect, payment, plan, password, Forgot) show a confirmation toast.
- Theme toggle flips light/dark via a `dk` class on `documentElement`, persisted to localStorage (wired on Teleon;
  roll out to all surfaces in production).
- Four states everywhere data renders: empty / loading (skeleton) / populated / error.

## State management

Single logic class per app (prototype) maps to route components in production. State: current route, selected
session, finding outcomes, filters, scope, mode, interruption budget, BYO key, demo text/result/error, members /
roles / invites, API keys (+ one-time reveal), notifications read flag, theme, toast. In production these move to the
datastore and the `/api/observer/*`, `/api/identity/`, `/registry/`, metering, and key services behind same-origin
seams; the finding card already renders the real `/api/observer/review` payload shape.

## Design tokens (the `.oh.dir-s.theme-light` scope)

- Surfaces: `--bg #fafaf8`, `--bg-subtle #f1f0ec`, `--panel #ffffff`, `--panel-2 #f8f7f3`.
- Lines: `--line #e7e5dd`, `--line-strong #d5d2c7`.
- Ink: `--fg #161513`, `--fg-muted #66635b`, `--fg-faint #868277`.
- Accent: per surface (see table); `--accent-ink #ffffff`; `--accent-weak = color-mix(in srgb, var(--accent) 14%, transparent)`.
- Semantic: `--success #1a7f37`, `--warning #9a6700`, `--danger #c0392b`, `--info #1f6fb2`, `--verified #0e7c86`.
- Primitive hues (OpenHubForAI): input `#5b6470`, knowledge `#1a7f37`, conditional `#9a6700`, action `#c2410c`,
  loop `#6e40c9`, output `#0969da`; stop uses `--danger`.
- Radii: `--r-sm 6px`, `--r-md 9px`, `--r-lg 12px`, `--r-pill 999px`.
- Shadows: `--e1 0 1px 2px rgba(40,30,20,.05)`, `--e2 0 12px 34px rgba(40,30,20,.11)`. Ease `cubic-bezier(.2,.8,.2,1)`.
- Type: UI **Inter**; display **Hanken Grotesk**; mono **JetBrains Mono**. H1 page title 30px/800; body 15px/1.6;
  eyebrow 11px uppercase, letter-spacing .14em. Sidebar 248px; content max-width 1040px; marketing max-width 1120px.
- Dark theme overrides (for the toggle): `--bg #121110`, `--panel #1b1a18`, `--line #2a2825`, `--fg #f2efe9`,
  `--fg-muted #a39e94`, `--verified #2dd4bf`, plus dark `--e1`/`--e2`.

## Assets

No external image assets; all UI is token-built (no SVG illustration, no raster). Fonts load from Google Fonts (Inter,
Hanken Grotesk, JetBrains Mono). Glyphs are Unicode (the brand marks: hub `⬢`, Teleon `⟳`, Baltor `◳`,
AIDevObserver `◉`, OpenHubForAI `⎔`). In the real codebase use the existing icon set; keep the brand marks.

## Files

- `AIDevObserver.dc.html` — the product (marketing + login + app), the primary reference.
- `AI Done Right.dc.html`, `Teleon.dc.html`, `Baltor.dc.html`, `OpenHubForAI.dc.html` — the family surfaces.
- `support.js` — the runtime that lets the `.dc.html` prototypes open in a browser (design-time only; not shipped).
- `INTEGRATION-HANDOFF.md` — the merge contract (kit, seams, proof gate, porting map).
- `PRODUCTION-PLAN.md` — the seven-stage path to a shipped product.
