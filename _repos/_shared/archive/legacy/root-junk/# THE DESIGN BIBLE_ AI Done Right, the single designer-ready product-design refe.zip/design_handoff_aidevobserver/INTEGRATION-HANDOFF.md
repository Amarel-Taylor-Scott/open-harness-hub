# AIDevObserver, integration handoff

> How to merge this design into the real codebase without breaking the one design law, the seams, the proof gate,
> or the copy rules. No em or en dashes anywhere (house rule). serves_truth = false on candidate output. A BYO key is
> used only for the request, never stored or logged.

## What this deliverable is

`AIDevObserver.dc.html` is a single self-contained Design Component that builds the AIDevObserver logged-in app to the
brief: the `OhAppShell` left sidebar, **Review** (default), **Sessions**, **Findings**, **Insights** (the leader view),
**Settings**, and a working **Demo**, plus the **finding card** (the core component) that renders the real
`/api/observer/review` payload fields, with **Accept / Reuse / Dismiss** outcomes.

It reproduces the shared kit values (`.oh.dir-s.theme-light` tokens, accent `#b25fd6`, the `.oh-*` atoms, `OhAppShell`)
as inline styles, because a Design Component paints inline as it streams. It does not fork or modify the kit; it
mirrors it 1 to 1, so porting back to the kit classes is mechanical.

## Where it lands

The app is `web/aidevobserver/` (React 18 via in-browser Babel, no build step), importing the shared kit at
`web/aidevobserver/kit/` (`oh-tokens.css`, `oh-components.css`, `oh-site.css`, `oh-site.jsx`, `products.js`). Served by
the showcase: `OH_PRODUCT=aidevobserver python3 -m scripts.showcase`.

Port the screens into `web/aidevobserver/aidevobserver-main.jsx` (add the logged-in `App` with `useHashRoute` and
`OhAppShell`; the marketing `Landing` already there stays). Put the bespoke finding card and the state pieces into
`web/aidevobserver/aidevobserver.css`, token-built. The brief already names them: `.ado-finding` (the card) and
`.ado-conf` (the confidence bar).

## Porting map (this DC to the real kit)

Each inline block maps to a kit class, because the DC uses the exact kit tokens already:

- root scope div  ->  `<div className={'oh dir-s theme-' + theme + ' oh-site'} style={{ '--accent': '#b25fd6' }}>`
- sidebar + account top bar  ->  `<OhAppShell brand nav={APP_NAV} route header={searchBtn} topbar={accountBar} cta>`
  where `APP_NAV` is the six items `[['/review','\u25c9','Review'], ['/sessions','\u25a4','Sessions'], ['/findings','\u2691','Findings'], ['/insights','\u25c8','Insights'], ['/settings','\u2699','Settings'], ['/demo','\u25b7','Demo']]`
- page head  ->  `<OhPageHead eyebrow title sub actions>`
- stat rollup  ->  `<OhRollup items>`
- cards and panels  ->  `.oh-card .oh-card--pad`
- buttons  ->  `.oh-btn .oh-btn--primary | --ghost | --sm`
- tables  ->  `.oh-table`
- the type chip and tone pills  ->  `.oh-badge` plus a small `.ado-type` token-built pill in `aidevobserver.css`
- the filter chips  ->  `.oh-segment` or token-built chips
- the mode rows and switches  ->  `.oh-setrow` plus `.oh-switch`
- the finding card  ->  `.ado-finding`; the confidence bar  ->  `.ado-conf` (or reuse `.ohs-meter`)
- skeleton, empty, and error states  ->  token-built in `aidevobserver.css`

## Wire the data (replace the seed with the seams)

The DC ships seeded `SESSIONS` and a local heuristic `runReview`. Replace them with the same-origin seams; the render
layer does not change.

- **Review:** `POST /api/observer/review` with `{ "messages": [...] }` or `{ "transcript_path": "..." }`. Render the
  `report` array as finding cards, ordered by `confidence` descending. Keep `serves_truth = false`.
- **Sessions:** `GET /api/observer/sessions` returns `{ "sessions": [ {session_id, path, mtime, project} ] }`. Show
  `project` plus a short `session_id` plus a relative `mtime`. Never show `path`.
- **Live (optional):** `POST /api/observer/live` for intra-session; the interruption budget caps `would_interrupt`.
- **Demo:** `POST` the example to `/api/observer/review` and render the same finding card. Swap the DC heuristic for
  the fetch.
- **Outcome:** persist Accept / Reuse / Dismiss to the review engine. That signal feeds the `agent_behavior` and
  `agent_qa` registries (AIDevObserver is the telemetry source that closes those two gaps).
- **Deep-link:** make a `source_ref.existing` chip open the OpenHubForAI `/browse` record for `{registry, name}` over
  the `/registry/` seam (147 catalog federation).
- Never hardcode a host; call the seam path (INTEGRATION-BIBLE section 4). A new endpoint is a service-plane service
  plus a seam, not a frontend hack.

## The one design law (do not break)

The shared kit is the only style source; the accent (`#b25fd6`) and the copy are the only per-surface variables. This
DC changes nothing in the kit. If a token or a component genuinely needs to change, change it in the kit so it
propagates to all five surfaces, and call it out; do not fork it into `aidevobserver.css`.

## Governance and copy

- `serves_truth = false` on candidate output; findings are suggestions a person triages, never gates; the tool is read
  only and stores nothing beyond the retention window; a BYO key is used only for the request, never stored or logged.
  The card footer and the page footer state this.
- Copy rules: no placeholders, no em or en dashes, no strategy leakage in public copy, real copy. The engine
  `message` and `suggestion` strings can contain em dashes; render them, but do not copy that punctuation into static
  copy.

## Files

- Added: `AIDevObserver.dc.html` (the design), `README.md` (orientation), `INTEGRATION-HANDOFF.md` (this file).
- Changed in the shared kit: none. Reproduced, not forked.
- New seam or service: none. Uses the existing `/api/observer/` seam, plus `/registry/` for the deep-links.

## How to verify

- The proof gate stays green: `PYTHONPATH=. python3 scripts/run_proofs.py`. The checks that cover this surface are the
  observer service self-test (`scripts/check_observer_local_service.py --self-test`) and the shared-kit checks if you
  touch any kit CSS (you should not).
- Served check: `OH_PRODUCT=aidevobserver python3 -m scripts.showcase`, then the app shows rich content with zero
  console errors, and the demo calls the real `/api/observer/review` and renders finding cards.
- The surface differs from the other four only by accent and copy, reuses the shared kit, and adds no new CSS system.

## Acceptance (from the brief), met in this design

- The `OhAppShell` left-sidebar shell with Review (default), Sessions, Findings, Settings, plus Insights and Demo, in
  the shared-kit look, accent `#b25fd6`.
- The finding card renders every payload field: the type chip toned by family (accent for the reinvention family,
  amber for waste, red for footgun, neutral for adversarial and guidance and alternative), the confidence, the
  message, the evidence (redacted and muted for footgun), the suggestion, and the `source_ref` chips
  (`existing` registry and name, or `covering` package and provides).
- Accept / Reuse / Dismiss on every finding, the outcome the product learns from, reflected on the Findings screen.
- Empty (a clean session), loading (skeleton cards), and error (the demo on invalid JSON) states.
- The demo runs a session and renders the same finding cards.
- Settings shows the mode, the interruption budget, the governed BYO-key field, the three install lines, and the
  internal-registry connect.
- The copy rules pass and the kit is not forked.

## Deeper integrations designed for (ready to wire)

- Registry deep-link: the `source_ref` chip opens the live OpenHubForAI record (the grounding that makes a finding
  trustworthy).
- Economics: the finding card shows reuse savings (dollars and hours), and Insights totals them. Source these from the
  economics registry (`src/teleon/economics`).
- Findings as governed objects: each finding is a candidate `RegistryObject` (`serves_truth = false`, the `outcome`
  field). The Findings screen is a view over these objects.
- Telemetry seam: the accept and dismiss outcomes populate the `agent_behavior` and `agent_qa` registries.
- Bring your own internal registry (Settings): so "already exists" also covers a team's private libraries, the
  highest-value catch.
