# PrimitiveLink-Bench protocol

**Version:** 0.1 research specification  
**Date:** July 9, 2026  
**Planned full matrix:** 120 long-form archetypes and 2,400 controlled instances  
**Empirical status:** not yet run

## 1. Objective

Determine whether a semantic primitive registry plus deterministic linker reduces total model-token and engineering cost on real software tasks while preserving or improving correctness, security, performance, reproducibility, maintainability, and human review burden.

The benchmark compares ordinary code generation, repository retrieval, primitive-document retrieval, compact graph linking, and graph linking with typed residual code.

## 2. Confirmatory hypotheses

1. Arm E lowers cache-weighted tokens per verified task relative to A and B.
2. Arm E is non-inferior on verified resolution, security, performance, and policy gates.
3. Arm D/E advantage increases with designed reusable share.
4. Removing hard blockers lowers first-graph validity and increases incorrect reuse.
5. Arm C is less efficient than D/E, establishing that savings come from deterministic linking rather than metadata alone.
6. Warm-registry savings eventually exceed ingestion, verification, index, and maintenance cost.

Pre-register the primary metric, non-inferiority margins, task exclusions, statistical tests, and stopping rules before running confirmatory tasks.

## 3. Systems under test

- **A: Full-context coding agent.** Agent reads/searches repository and writes source normally. Constraint: No primitive registry.
- **B: Repository RAG agent.** Agent receives lexical/dense code chunks but still writes implementation. Constraint: Same model/tool budget as A.
- **C: Primitive-doc RAG agent.** Agent receives primitive descriptions/source snippets and writes source. Constraint: No deterministic assembly.
- **D: Compact graph + deterministic linker.** Agent emits only capability graph; linker resolves and assembles. Constraint: Residual code prohibited; record abstentions.
- **E: Linker + bounded residuals.** Known graph is linked; agent writes only isolated novel adapters/business logic. Constraint: Residual interface and tests required.
- **F: Oracle capability mapping.** Human-curated or task-generator mapping supplies correct primitive set. Constraint: Still uses normal resolver/assembler.
- **G: Deterministic template/library lower bound.** No LLM; prewritten task-specific automation where available. Constraint: Only applicable to covered tasks.

All non-oracle arms receive the same issue text, repository snapshot, environment, allowed tools, time budget, and hidden evaluator. Within a block, use the same planner model/version, scaffold, system policy, temperature, and random seed.

## 4. Corpus construction

Use three complementary sources:

1. **Public verified tasks.** Curated repository tasks such as SWE-bench Verified and other executable repository benchmarks, subject to license and contamination checks.
2. **Private/post-cutoff tasks.** Organization repositories or newly constructed tasks inaccessible during model pretraining.
3. **Mutated and generated tasks.** Semantics-preserving repository mutations, renamed domain concepts, new schemas, altered dependencies, and adversarial near-miss registries.

For each task, build:

```text
repository snapshot
container/toolchain digest
issue specification
public tests
hidden functional tests
security and policy checks
performance checks where applicable
gold capability graph
gold implementation set
gold novelty boundary
invalid near-miss set
registry snapshot
evaluation script digest
```

The gold graph remains hidden from tested systems.

## 5. Experimental factors

### Task family

- Greenfield endpoint: Add a production-ready HTTP endpoint with validation, authorization, persistence, error mapping, observability, and tests.
- Multi-file CRUD: Implement create/read/update/delete behavior across handlers, domain services, repositories, schemas, and integration tests.
- Authentication flow: Introduce an access-token or session flow with secure credential handling, rotation, revocation, and audit evidence.
- Database migration: Evolve a live schema and application code without data loss or unsafe downtime.
- Event pipeline: Add a producer-consumer workflow with schema validation, retries, deduplication, dead-letter handling, and tracing.
- External API integration: Integrate a versioned external service with authentication, retries, rate limits, caching, and failure isolation.
- Framework upgrade: Upgrade a framework/runtime across a repository while preserving behavior and removing deprecated APIs.
- Dependency security patch: Remediate a vulnerable dependency with the smallest safe change and verified provenance.
- Performance optimization: Reduce latency or resource use while preserving semantics under realistic workload tests.
- Concurrency bug: Repair a race, deadlock, ordering, or cancellation bug in concurrent code.
- Flaky test: Diagnose and eliminate a nondeterministic test without hiding a production defect.
- CI/build repair: Repair a failing build pipeline across toolchain, cache, platform, and packaging boundaries.
- Observability rollout: Add consistent metrics, traces, logs, dashboards, and alerts without leaking sensitive data.
- Error standardization: Replace inconsistent exceptions and response shapes with a stable domain-to-transport error model.
- Refactor to interface: Extract a stable interface and migrate implementations/callers without behavioral regression.
- Cross-language RPC: Connect services in different languages with versioned schemas, error semantics, and observability.
- Frontend feature: Add a user-facing feature spanning UI state, accessibility, API integration, errors, analytics, and tests.
- Data pipeline: Build or modify an ingestion and transformation pipeline with validation, lineage, idempotency, and recovery.
- Agent workflow: Implement a multi-step agent workflow with tool discovery, approvals, memory limits, and deterministic validation.
- Policy enforcement: Add a cross-cutting rule for data access, dependency use, deployment, or code architecture.

### Scope

- Single module: One primary module and its unit tests; approximately 1–5 KLOC of immediately relevant code.
- Small feature: Three to eight files across one service; approximately 5–20 KLOC of relevant repository context.
- Repository issue: A realistic issue spanning 10–40 files in one repository with build and integration tests.
- Cross-cutting repository: A change touching multiple layers, configuration, CI, documentation, and 30–100 files.
- Multi-repository: Two to five versioned repositories or services with release coordination and compatibility tests.
- Long-horizon chain: A sequence of four related tasks on an evolving codebase; later tasks can reuse validated earlier outcomes.

### Reusable share

0%, 25%, 50%, 75%, 90%, and 100%.

### Registry state

* **Cold:** no outcome telemetry; only initial evidence.
* **Warm:** prior successful uses and quality outcomes are available.
* **Stale:** versions or evidence have aged and migration candidates exist.
* **Adversarial:** misleading descriptions, same-signature near misses, untrusted artifacts, and incompatible versions are present.

### Search stress

Vary partition size, duplicate density, near-miss density, missing metadata, corrupted descriptions, and revoked artifacts.

### Model and scaffold

At least three planner model families, two agent scaffolds, and three seeds. Run a local/open model block where possible so the finding is not dependent on one hosted provider.

## 6. Run procedure

1. Freeze all model, tool, price, repository, registry, and policy versions.
2. Reset the repository and all mutable services.
3. Randomize arm order within each task/model/scaffold/seed block.
4. Start immutable event and token logging before the first model request.
5. Enforce identical time, turn, tool, and permission budgets.
6. Record every retrieval query, candidate set, blocker decision, score, graph, lock, diff, test, and diagnostic.
7. Terminate on verified success, explicit abstention, budget exhaustion, unrecoverable policy denial, or timeout.
8. Run the pinned evaluator independently from the agent.
9. Preserve failed working trees and logs.
10. Randomly sample successful and failed runs for blinded human review.
11. For long-horizon chains, carry forward only code and approved persistent state defined by the protocol.
12. Compute raw metrics from the immutable ledger; never reconstruct token usage from displayed text alone.

## 7. Token ledger

Record provider-reported categories and independent tokenizer counts when possible:

```json
{
  "uncached_input_tokens": 0,
  "cached_input_tokens": 0,
  "output_tokens": 0,
  "reasoning_tokens": 0,
  "tool_schema_tokens": 0,
  "retrieved_context_tokens": 0,
  "diagnostic_tokens": 0,
  "repair_tokens": 0,
  "residual_tokens": 0,
  "embedding_input_tokens": 0,
  "rerank_pairs": 0
}
```

Compute:

```text
T_raw = uncached_input + cached_input + output + exposed_reasoning

T_cache_weighted(w) =
  uncached_input + w*cached_input + output + exposed_reasoning

raw_savings = 1 − T_treatment / T_baseline

verified_token_efficiency =
  verified_tasks * 1,000,000 / T_cache_weighted

cost_per_verified_task =
  sum(all model, retrieval, verification, and infrastructure cost)
  / verified_tasks
```

Report `w = 0`, actual provider billing weight, and `w = 1`.

## 8. Success gates

A run is verified only when every required gate passes:

* repository builds from a clean state;
* type check and lint pass when part of the repository contract;
* public and hidden functional tests pass;
* security and policy checks pass;
* performance threshold passes for performance-sensitive tasks;
* artifacts and lock reproduce;
* no forbidden effect or unauthorized data exposure occurred.

Abstention is not success, but measure abstention precision and cost separately. A safe abstention can be preferable to an invalid automatic patch.

## 9. Primary and secondary metrics

The workbook includes 132 metrics. Confirmatory reporting should emphasize:

```text
verified resolution rate
cache-weighted tokens per verified task
verified tasks per million tokens
cost per verified task
wall-clock time per verified task
first-graph valid rate
post-apply human edit distance
security/policy/performance gate rates
```

Retrieval diagnostics include capability and implementation recall at several cutoffs, MRR, nDCG, quality-valid recall, policy-valid recall, duplicate rate, diversity, and hard-negative rejection.

Linker diagnostics include graph solution rate, solver expansions, adapter count/depth, residual count, lock resolution, deterministic apply, and repair iterations.

## 10. Human review

Blind reviewers to the arm when feasible. For a stratified sample, measure:

* correctness not captured by tests;
* architectural fit;
* readability and maintainability;
* unnecessary changes;
* documentation quality;
* security and privacy concerns;
* estimated minutes to accept or repair;
* normalized edit distance.

Use at least two reviewers per sampled task and report agreement.

## 11. Statistical analysis

Use a paired randomized block design. The unit of pairing is task × snapshot × model × scaffold × seed.

* Binary outcomes: McNemar test or paired permutation, plus confidence interval for paired difference.
* Tokens, cost, latency, edit distance: paired bootstrap and Wilcoxon/permutation analysis.
* Heterogeneity: mixed-effects models with task/repository random effects.
* Interactions: arm × reuse share, arm × registry state, arm × scope, arm × model.
* Pareto analysis: verified success against tokens, cost, latency, edit distance, and safety.
* Multiple tests: predeclare a small confirmatory family; label the remainder exploratory.
* Heavy tails: report medians, means, p25/p75, p90/p95, and full empirical distributions.

Do not delete expensive failures. Infrastructure failures should be separately labeled but included under pre-registered rules.

## 12. Amortization experiment

For each primitive family, record one-time and recurring costs:

```text
ingestion
contract authoring
description generation and verification
test and security evidence
legal/provenance review
embedding and index build
compatibility refresh
deprecation and incident maintenance
```

Then replay realistic arrival rates and calculate cumulative net value. Report break-even with uncertainty and sensitivity to model prices, cache discounts, registry refresh frequency, and human review cost.

## 13. Required ablations

At minimum:

1. lexical only;
2. dense only;
3. hybrid retrieval;
4. no negative descriptions;
5. no blockers;
6. types-only blockers;
7. full blockers;
8. no quality evidence;
9. float16 versus int8 versus PQ;
10. no graph solver;
11. greedy versus bounded A*/beam;
12. no residuals versus typed residuals;
13. cold versus warm telemetry;
14. stale and adversarial registries;
15. full source context versus compact primitive sketches;
16. oracle mapping.

The workbook supplies 80 ablation rows.

## 14. Release requirements

A publishable benchmark release should include:

* task and dataset card;
* licenses and provenance;
* task-construction scripts;
* container and dependency digests;
* hidden-test escrow process;
* registry generation process;
* gold-graph annotation guide;
* run-log schema;
* tokenizer and price snapshots;
* baseline implementations;
* contamination analysis;
* security review;
* reproducibility instructions;
* an explicit statement that no empirical result exists until runs are completed.

## 15. Pilot decision thresholds

Before scaling beyond 100,000 primitives, require all of the following on at least one high-frequency family:

* statistically supported lower tokens per verified task than A and B;
* no material loss in verified success;
* non-inferior security, policy, and performance results;
* lower median human edit distance;
* meaningful first-graph validity;
* a plausible amortized break-even interval;
* stable results on private or mutated tasks;
* no dependence on oracle mapping.

Failure to meet these criteria is a useful result: it means the registry, descriptions, blockers, graph solver, or economic target needs redesign before 50M-scale investment.
