# Research report: a 50-million-plus semantic primitive registry for LLM development

**Research snapshot:** July 9, 2026  
**Status:** architecture, literature synthesis, data dictionary, and experimental specification. This is **not** an empirical claim that the proposed linker has already produced the projected savings.

## Executive conclusion

The idea is technically credible, but its success depends much less on whether an approximate-nearest-neighbor system can index 50 million vectors than on whether the registry can distinguish a *semantically relevant* primitive from one that is incompatible, obsolete, insecure, untrusted, behaviorally wrong, or expensive in the current workspace.

The strongest architecture is a semantic linker:

```text
task intent
  → compact typed/effect-aware goal graph
  → partitioned hybrid retrieval
  → hard compatibility and policy blockers
  → quality/evidence reranking
  → bounded graph synthesis
  → exact implementation resolution
  → deterministic assembly
  → compiler, tests, policy, security, and performance verification
  → outcome learning
```

The system should minimize language-model work according to:

```text
solution = verified reusable graph + verified adapters + isolated novel residual
```

The intended economic property is:

```text
model-token consumption should scale with novelty,
not with the number of already-solved implementation lines.
```

The literature provides strong adjacent evidence for all major components:

* [DreamCoder](https://arxiv.org/abs/2006.08381) and [LILO](https://arxiv.org/abs/2310.19791) show that recurring solutions can be compressed into learned libraries and that natural-language names and documentation can improve use of those abstractions.
* [SyPet](https://dl.acm.org/doi/10.1145/3009837.3009851) and [APIphany](https://arxiv.org/abs/2203.16697) show that typed or semantically typed components can be composed by symbolic search rather than regenerated.
* [CoIR](https://arxiv.org/abs/2407.02883), [CoRNStack](https://arxiv.org/abs/2410.01026), [CoSQA+](https://arxiv.org/abs/2406.11589), and [CoQuIR](https://arxiv.org/abs/2506.11066) show why code retrieval needs diverse tasks, hard negatives, executable evidence, and quality dimensions beyond topical relevance.
* [BEIR](https://arxiv.org/abs/2104.08663), [BGE-M3](https://arxiv.org/abs/2402.03216), [SPLADE](https://arxiv.org/abs/2107.05720), [ColBERTv2](https://arxiv.org/abs/2112.01488), and [PLAID](https://arxiv.org/abs/2205.09707) support a hybrid first stage followed by more expensive reranking.
* [HNSW](https://arxiv.org/abs/1603.09320), [DiskANN](https://papers.nips.cc/paper/2019/hash/09853c7fb1d3f8ee67a61b6bf4a7f8e6-Abstract.html), [SPANN](https://arxiv.org/abs/2111.08566), product quantization, and the [BigANN benchmark](https://big-ann-benchmarks.com/) establish that 50 million vectors are manageable with the right memory/disk and compression design.
* [RepoFormer](https://arxiv.org/abs/2403.10059) reports that always retrieving repository context can be unhelpful or harmful and that selective retrieval produced up to a 70% online-serving inference speedup in its evaluated completion setting.
* [AgentDiet](https://arxiv.org/abs/2509.23586) reports 39.9–59.7% input-token reduction and 21.1–35.9% total computational-cost reduction in its evaluated coding-agent settings while maintaining its measured performance.
* [SWE-Replay](https://arxiv.org/abs/2601.22129) reports up to 17.4% lower cost and up to 3.8% better performance than naive repeated test-time sampling on SWE-bench Verified in its experiments.
* [SWE-Effi](https://arxiv.org/abs/2509.09853) demonstrates why resolution rate alone is inadequate: model/scaffold pairings can consume radically different token budgets for substantially different outcomes.

These results do **not** directly prove the semantic-linker thesis. They establish that selective context, reuse, retrieval, component composition, and resource-aware evaluation can work. The workbook therefore specifies a controlled benchmark that can falsify the stronger claim.

## 1. What counts as a primitive

A primitive is not necessarily a source file, function, package, or remote tool. It is a versioned abstract capability with one or more concrete implementations.

```text
Capability:
  "verify an access token under policy X"

Possible implementations:
  a local Rust function
  a TypeScript package export
  a WebAssembly component
  an internal identity service
  an MCP tool used only during an agent run
```

A practical registry separates:

| Object | Meaning |
|---|---|
| Capability | Abstract behavior the planner requests. |
| Implementation | Concrete source, package export, service, component, binary, or tool. |
| Adapter | Verified conversion between types, protocols, effects, versions, or frameworks. |
| Recipe | Reusable graph of capabilities. |
| Binding | Choice of exact implementations for a workspace. |
| Lock | Exact versions, digests, policies, graph, toolchain, and evidence needed to reproduce the result. |
| Residual | Novel code isolated behind a typed and effect-declared boundary when no verified primitive is adequate. |

This distinction prevents micro-package explosion. The planner may reason at fine semantic granularity while the resolver coalesces many capabilities into one ordinary package or service deployment.

## 2. A semantic ABI

A signature such as `string → string` is almost useless for safe composition. A semantic application binary interface should model:

```text
P : (inputs, configuration, state)
      → (outputs, typed errors, new state)
```

and declare:

* nominal and structural types;
* refinement predicates, units, ranges, normalization, and data classes;
* preconditions, postconditions, invariants, and frame conditions;
* synchronous, asynchronous, streaming, batch, pagination, cancellation, and timeout behavior;
* idempotency, retry safety, atomicity, consistency, isolation, durability, compensation, and delivery semantics;
* filesystem, network, database, queue, secret, process, browser, payment, email, identity, logging, and model-provider effects;
* security, privacy, license, provenance, trust, operational, latency, memory, and cost constraints;
* contract, property, fuzz, conformance, security, performance, and production evidence.

The workbook's **Registry Fields** sheet contains **667 proposed columns in 25 categories**. This is a logical superset, not a recommendation for one physically wide SQL table. Arrays and graph edges should be normalized; full evidence and artifacts belong in object storage; only high-selectivity serving fields should be materialized in search indexes.

The most important rule is that unknown metadata is not silently equivalent to a safe value. A primitive with no declared network effects is not automatically network-free. Safety-critical unknowns should fail closed or remain in a quarantined tier.

## 3. Natural-language descriptions as retrieval views

The workbook defines **336 language views** from 42 facets and 8 linguistic styles.

The facets include purpose, goal, transformation, inputs, outputs, preconditions, postconditions, invariants, effects, permissions, failure conditions, retry behavior, transactions, security, privacy, performance, compatibility, upstream and downstream context, alternatives, anti-use cases, near misses, positive examples, counterexamples, bug symptoms, stack-trace paraphrases, test oracles, migration guidance, rationale, and limitations.

The styles include canonical statements, first-person intents, imperative requests, questions, diagnostic queries, domain synonyms, terse keywords, and scenario narratives.

These views serve different retrieval functions:

* **Recall views:** user intents, questions, domain synonyms, and scenario narratives.
* **Precision views:** preconditions, semantic transformations, types, effects, and compatibility.
* **Negative views:** anti-use, near-miss, counterexample, security violation, and failure semantics.
* **Diagnostic views:** symptoms, logs, stack traces, test failures, and migration problems.
* **Explanation views:** rationale, limitations, evidence, and alternatives.

The key operational conclusion is not to store all 336 sentences for every primitive. At 50 million primitives, that would create **16.8 billion description records**. At an illustrative 25 tokens each, it would be **420 billion tokens** and roughly **1.68 TB of raw text at four characters per token**, before an inverted index, vectors, replicas, metadata, or object overhead.

A better design is:

1. Persist approximately 12–32 core evidence-linked views for every verified primitive.
2. Persist additional views only for high-value or ambiguity-prone primitives.
3. Generate tail views on demand and cache them when retrieval telemetry justifies it.
4. Store generator model/version, evidence pointers, verifier decision, and confidence for every generated claim.
5. Use independent model generations to increase coverage, but require source/test evidence rather than model consensus.
6. Build adversarial negative views deliberately. A same-signature primitive with the wrong transaction or retry semantics is a valuable training negative.

Embeddings generated by different model families occupy unrelated spaces. Their vectors should not be averaged. Keep separate indexes or features and combine ranks with reciprocal-rank fusion, calibrated score fusion, or a learned reranker.

## 4. Blocking variables

The workbook defines **360 blockers across 18 categories**. These are predicates that can disqualify a candidate even when it is semantically close.

Representative categories are:

* tenant, organization, workspace, repository, namespace, and visibility;
* lifecycle, maturity, deprecation, compatibility epoch, and version ranges;
* language, compiler, runtime, framework, SDK, operating system, CPU, GPU, ABI, and container;
* packages, dependencies, build flags, features, reproducibility, and supply-chain risk;
* invocation, signature, async/streaming/pagination/cancellation behavior;
* nominal types, structural shapes, refinements, units, session types, and state types;
* input/output cardinality, nullability, encoding, size, ordering, ownership, and lifetime;
* preconditions, postconditions, determinism, idempotency, atomicity, consistency, and losslessness;
* filesystem, network, database, queue, secret, process, browser, and communication effects;
* transactions, protocols, concurrency, locking, ordering, delivery, backpressure, and checkpoints;
* security, privacy, cryptography, data classification, residency, and human approval;
* license, provenance, signatures, SBOMs, export control, trust tier, and revocation;
* latency, throughput, memory, CPU/GPU, network, complexity, energy, and cost;
* reliability, observability, rollback, disaster recovery, evidence strength, freshness, and workspace architecture.

Blocking should be staged:

```text
before candidate exposure:
  tenant, visibility, access-control, registry tier

during partition routing:
  language, runtime, framework, primitive kind, broad domain

after high-recall retrieval:
  types, refinements, effects, versions, protocols, licenses, trust

before graph acceptance:
  behavior, transactions, concurrency, security, privacy, resources

before execution or materialization:
  exact artifact digest, signature, provenance, policy, build and tests
```

Embedding similarity is evidence of possible relevance. It cannot establish authorization, license compatibility, ABI compatibility, retry safety, transaction participation, or the absence of a forbidden effect.

## 5. Embedding and retrieval design

The workbook defines **360 logical channels**:

```text
40 semantic evidence views
× 3 scopes: primitive, recipe/composition, workspace/neighborhood
× 3 representations: dense, sparse, late interaction
= 360 logical channels
```

This matrix is a research design space. Physically storing every channel would be a serious mistake.

### 5.1 Recommended physical representations

**Lexical and learned sparse**

Use trigram/symbol search, BM25, SPLADE-like expansion, or BGE-M3 sparse outputs for identifiers, package coordinates, exact types, versions, error codes, logs, API names, and rare domain terms. Lexical search remains essential because exact symbolic evidence is often more discriminative than semantic similarity.

**Dense single vectors**

Use a small number of global channels for purpose/goal, canonical contract, code, tests, failure semantics, and perhaps security/effects. Candidate families in the workbook include code-specialized, multilingual, open, hosted, small, and high-capacity encoders. Every candidate must be evaluated on the proposed primitive benchmark rather than selected from a general embedding leaderboard.

**Graph and structural features**

Store call, data-flow, control-flow, type, package, recipe, and successful-composition relations in a compressed graph. Node, graph, and knowledge-graph embeddings can support candidate generation, but raw graph traversal and exact typed relations should remain available.

**Late interaction and cross-encoder reranking**

Use ColBERT-like token vectors, PLAID, or cross-encoders only on a shortlist, a premium verified tier, or a frequently queried cache. They can improve subtle alignment but are too expensive to treat as hundreds of global token-vector channels.

### 5.2 Scale calculations

For 50 million primitives and 768 dimensions:

| Materialization | Raw storage |
|---|---:|
| One float32 channel | 153.6 GB |
| One float16 channel | 76.8 GB |
| One int8 channel | 38.4 GB |
| One 768-bit binary channel | 4.8 GB |
| One illustrative PQ64 channel | 3.2 GB |
| 300 float32 channels | 46.08 TB |
| 360 float32 channels | 55.296 TB |
| Eight PQ64 channels | 25.6 GB |
| Two int8 channels | 76.8 GB |
| One illustrative 32×128 int8 late-interaction channel | 204.8 GB |

These are raw payloads only. Real deployment adds ANN graph or partition structures, posting lists, primary metadata, graph edges, replicas, snapshots, staging, compaction, and capacity headroom.

A credible starting materialization is:

```text
global:
  one lexical index
  one learned sparse index
  6–12 compressed dense channels
  exact metadata and blocker fields
  compact graph relations and fingerprints

hot tier:
  1–3 high-recall float16/int8 HNSW channels for the most used 5–10M objects

cold tier:
  DiskANN/SPANN/IVF-PQ or equivalent over all visible objects

shortlist:
  token-level late interaction or cross-encoder quality/semantic reranking

on demand:
  tail description views, workspace-conditioned embeddings, expensive behavioral views
```

### 5.3 Candidate funnel

A representative funnel is:

```text
50,000,000 visible objects
  → 500,000–5,000,000 after hard routing
  → 2,000–10,000 from each parallel retriever
  → 1,000–3,000 after fusion and deduplication
  → 100–500 after hard blockers
  → 20–100 after semantic and quality reranking
  → 1–20 candidate graphs
  → 1–5 exact locks
  → zero or one accepted verified result
```

The exact numbers are workload-dependent. The benchmark should measure recall and latency at every boundary instead of treating the search engine as one opaque component.

## 6. Search and graph synthesis

The retrieval target is not a single nearest primitive. It is a minimum-cost valid graph that reaches requested outputs from available inputs and state.

A candidate objective can combine:

```text
semantic match
+ exact symbol/type match
+ graph compatibility
+ workspace compatibility
+ evidence strength and freshness
+ trust and provenance
+ historical success
− adapter depth
− residual-code cost
− operational cost
− security and maintenance risk
```

Hard constraints are not weights. A denied network destination should not become acceptable because its semantic score is high.

A practical graph solver should:

1. Work backward from requested outputs and required postconditions.
2. Expand only capabilities whose output types, refinements, errors, and effects can contribute.
3. Prefer verified recipes and cached subgraphs.
4. Use bounded A*, beam search, type-directed reachability, or Petri-net-like abstractions.
5. Insert only verified adapters.
6. Bound graph depth, adapter depth, and solver expansions.
7. Return compiler-like diagnostics for unsatisfied types, effects, protocols, and policy.
8. Isolate unresolved novelty instead of forcing a misleading reuse.

The plan language should remain a compact declarative graph IR. If it becomes a general-purpose programming language, the model will simply emit large programs in another syntax and the token advantage will disappear.

## 7. Self-tuning search

The learning signal should be ordered by evidence strength:

```text
impression
< click
< selection
< graph resolution
< compilation
< contract-test pass
< hidden-test pass
< small human edit distance
< merge
< deployment
< rollback-free production window
< no associated incident
```

Post-assembly edit distance is especially valuable. It measures whether a result was genuinely compatible with the repository rather than merely test-passing under a narrow fixture.

The learning system should preserve exploration. Pure popularity ranking creates a feedback loop in which early primitives dominate and new implementations never gather evidence. Use controlled exploration, counterfactual logging, protected offline sets, freshness decay, and quality priors.

Telemetry should remain local or privacy-preserving by default. Raw prompts, proprietary source, secrets, and production payloads should not enter a global learning warehouse.

## 8. Security and supply-chain design

The registry becomes both an execution surface and a software supply chain. Each implementation should carry:

* content and semantic digests;
* exact source revision and artifact media type;
* publisher and signer identity;
* build provenance and reproducibility result;
* SBOM, license expression, and notices;
* dependency closure and vulnerability status;
* test, fuzz, static-analysis, conformance, and performance evidence;
* declared effect capabilities and data classes;
* trust tier, revocation status, and policy approvals.

Use federated tiers:

```text
workspace-local
organization-private
approved vendor
verified public
untrusted/quarantine
```

Search can inspect several tiers when policy permits, but automatic assembly should use only allowed and sufficiently evidenced tiers. Artifact provenance proves origin and build process; it does not prove semantic correctness. Tests and behavioral contracts remain necessary.

## 9. The model catalog

The workbook contains **108 candidate methods and model families**, including:

* lexical and sparse baselines;
* hosted and self-hosted general embeddings;
* multilingual and code-specialized encoders;
* source, AST, data-flow, graph, binary, and behavior representations;
* late-interaction engines;
* cross-encoder and generative rerankers;
* graph and knowledge-graph embeddings.

This is a candidate pool, not an operational recommendation. Production should usually deploy a handful of complementary models:

```text
1 cheap query/description encoder
1 code-specialized encoder
1 learned sparse model or lexical expansion method
1 optional graph/structural model
1 shortlist reranker
1 open local fallback
```

Model selection must consider:

* primitive retrieval recall and hard-negative rejection;
* quantized recall per byte;
* query and batch-encoding latency;
* source-code privacy and allowed deployment region;
* license and model provenance;
* multilingual and programming-language coverage;
* compatibility of old and new vectors during migration;
* incremental update behavior;
* model cost and re-encoding cost;
* stability under adversarial documentation.

Current hosted model availability and pricing are time-sensitive; recheck official documentation before procurement.

## 10. PrimitiveLink-Bench

The workbook specifies **120 long-form task archetypes and 2,400 controlled instances**.

### 10.1 Core hypotheses

**H1 — verified token reduction**  
The linker-plus-residual treatment uses fewer cache-weighted tokens per verified task than a normal coding agent and a repository-RAG agent.

**H2 — savings scale with reuse**  
The treatment advantage increases monotonically as the designed reusable share rises from 0% to 100%.

**H3 — no quality regression**  
Security, performance, policy, reproducibility, and human edit-distance outcomes are non-inferior to the strongest baseline.

**H4 — hard blockers matter**  
Removing type, effect, version, policy, or provenance blockers increases incorrect reuse and lowers first-graph validity.

**H5 — retrieval is not the entire gain**  
Primitive-doc RAG improves over ordinary RAG, but a compact graph plus deterministic linker improves token efficiency further by removing implementation emission.

**H6 — warm reuse amortizes ingestion**  
After enough repeated uses, cumulative avoided agent work exceeds primitive ingestion, verification, indexing, and maintenance cost.

### 10.2 Experimental arms

| Arm | System |
|---|---|
| A | Full-context coding agent. |
| B | Repository lexical/dense RAG; agent still writes source. |
| C | Primitive documentation/source RAG; agent still writes source. |
| D | Compact graph plus deterministic linker; no residual code. |
| E | Linker plus typed, bounded residual generation. |
| F | Oracle primitive mapping; retrieval upper bound. |
| G | Deterministic task-specific automation; applicable lower cost bound. |

Arms A–E must use the same planner model, scaffold permissions, time limits, tool policy, and hidden tests within each randomized block. Additional blocks should test at least three planner models, two scaffolds, and three seeds.

### 10.3 Task matrix

The 20 task families are:

1. greenfield endpoint;
2. multi-file CRUD;
3. authentication flow;
4. database migration;
5. event pipeline;
6. external API integration;
7. framework upgrade;
8. dependency security patch;
9. performance optimization;
10. concurrency bug;
11. flaky test;
12. CI/build repair;
13. observability rollout;
14. error standardization;
15. refactor to interface;
16. cross-language RPC;
17. frontend feature;
18. data pipeline;
19. agent workflow;
20. policy enforcement.

Each appears at six scopes:

* single module;
* small feature;
* repository issue;
* cross-cutting repository change;
* multi-repository change;
* long-horizon chain.

Each instance varies designed reusable share, registry state, language/framework, near-miss density, and seed. Registry states include cold, warm, stale, and adversarial.

### 10.4 Reuse strata

Tasks should be generated or curated at 0%, 25%, 50%, 75%, 90%, and 100% reusable-share targets. The gold mapping remains hidden from the tested system.

The realized reusable share is independently audited after execution:

```text
observed reusable share =
  verified linked semantic work
  /
  total verified semantic work
```

Lines of code are not the denominator because one novel line can contain more semantic work than hundreds of generated boilerplate lines.

### 10.5 Real long-form task construction

Every task needs:

* a pinned repository and toolchain;
* a natural issue specification;
* public acceptance tests;
* hidden functional tests;
* hidden hard-negative tests;
* task-specific security and policy checks;
* performance checks where applicable;
* a human-reviewed gold capability graph;
* a gold novelty boundary;
* multiple plausible but invalid primitive candidates;
* exact licenses and provenance for all fixtures;
* a deterministic mock for external services;
* a resettable container and dependency cache policy.

The **Long-form Scenarios** sheet supplies detailed prompts for all 120 family/scope combinations. The JSONL manifest expands them into 2,400 controlled rows.

### 10.6 Token accounting

Do not report a single provider bill as “tokens.” Preserve:

```text
uncached input tokens
cached input tokens
output tokens
reasoning tokens when exposed
tool-schema tokens
retrieved context tokens
diagnostic/test-output tokens
repair-loop tokens
residual-generation tokens
embedding input tokens
reranker inputs
```

Report at least three accounting views:

```text
T_raw =
  all model input + all output

T_provider_actual =
  provider-billed token categories and prices at run time

T_cache_weighted(w) =
  uncached input
  + w × cached input
  + output
  + exposed reasoning
```

where `w` is reported at 0, actual provider billing weight, and 1. This prevents conclusions from depending on one transient cache price.

Embedding and search compute should be reported separately in USD, CPU/GPU time, energy, storage, and latency. An optional token-equivalent transformation may be shown, but raw physical measures must remain available.

### 10.7 Primary outcomes

A task is verified only if all mandatory gates pass. The primary metrics are:

```text
verified resolution rate

cache-weighted tokens per verified task

verified token efficiency =
  verified tasks × 1,000,000
  / cache-weighted tokens

cost per verified task =
  all run, search, embedding, verification, and infrastructure cost
  / verified tasks

post-assembly human edit distance

first-graph valid rate
```

Failed runs remain in the numerator of tokens, cost, and time and contribute zero verified tasks. A treatment cannot improve efficiency by cheaply failing.

### 10.8 Statistical design

Use a paired randomized block design:

```text
block:
  task × repository snapshot × model × scaffold × seed

randomized within block:
  arm execution order
```

Use:

* paired bootstrap confidence intervals for token, cost, time, and edit-distance differences;
* McNemar or paired permutation tests for binary success;
* Wilcoxon or permutation tests for skewed paired continuous values;
* mixed-effects models with task/repository random effects and arm, reuse, registry state, model, and scope fixed effects;
* interaction terms, especially arm × reusable share and arm × adversarial registry;
* Pareto frontiers for verified success, tokens, cost, latency, safety, and maintainability;
* correction for multiple confirmatory hypotheses;
* pre-registered exclusions and no silent removal of failed infrastructure runs.

Report distributions rather than only means. Agent token use can have heavy tails and large repeated-run variance.

### 10.9 Amortization

Primitive ingestion has a real cost:

```text
C_create =
  discovery + normalization + descriptions + tests
  + security/legal review + indexing + maintenance
```

For capability family `f`:

```text
break_even_uses_f =
  C_create_f
  /
  E[cost_baseline_success − cost_linker_success]
```

The denominator must include differences in failure rate, repair, review, rollback, and maintenance—not only generation tokens.

Report cumulative net value over time:

```text
net value(t) =
  avoided agent cost
  + avoided human edit/review cost
  + avoided incident/rollback cost
  − ingestion
  − verification
  − index serving
  − refresh and deprecation maintenance
```

The system may be economically valuable for authentication, CRUD, observability, queue handling, cloud integrations, migrations, and test scaffolding while being uneconomic for rare bespoke algorithms. Measure by family.

## 11. Falsification and go/no-go criteria

The initial pilot should be considered unsuccessful when any of the following occur:

* token savings vanish after conditioning on verified success;
* the advantage exists only against an intentionally weak baseline and not against context pruning or selective RAG;
* first-graph validity remains low despite high retrieval recall;
* hard-negative or policy failures rise;
* human edit distance or review time is not lower;
* primitive ingestion and verification do not approach break-even in high-frequency families;
* plans become nearly as verbose as generated source;
* adapter depth grows without bound;
* the best results require an oracle mapping;
* public benchmark gains do not reproduce on private, post-cutoff, or mutated tasks.

A credible pilot success target is not “90% fewer tokens.” It is a statistically supported improvement in verified tokens per task, cost per verified task, first-pass validity, and edit distance on at least one high-frequency domain, with no material safety or performance regression.

## 12. Recommended implementation sequence

### Phase 0: falsification study

* One or two languages and frameworks.
* 5,000–20,000 trusted internal capabilities.
* 500+ paired tasks.
* Lexical, one sparse, two dense channels, and a small reranker.
* Approximately 60 high-value blockers.
* Deterministic AST/config backend.
* Arms A, B, D, and E.
* Immutable token and outcome ledger.

### Phase 1: trusted internal registry

* 100,000 verified capabilities and recipes.
* Full semantic ABI for the chosen stacks.
* Signed artifacts, provenance, SBOM, and license policy.
* Automatic residual isolation and candidate promotion into quarantine.
* MCP server exposing a small fixed meta-tool set: profile, search, expand, solve, apply, verify, promote.

### Phase 2: million scale

* Disk-backed ANN and hot/cold tiers.
* Quality and production-outcome reranking.
* Compatibility test farm.
* Multi-tenant policy and local/private indexing.
* Counterfactual ranking evaluation.

### Phase 3: cross-language and service components

* WIT, RPC, service, container, and package implementations.
* Canonical semantic types and verified adapters.
* Cross-language benchmark arms.

### Phase 4: 50M federation

* Workspace, organization, approved-vendor, verified-public, and quarantine registries.
* Filtered ANN, revocation, trust roots, privacy-preserving outcome learning.
* Capacity planning from measured query distributions, not the 360-channel logical maximum.

## Final recommendation

Build the benchmark and a narrow prototype before building the corpus.

The decisive experiment is not whether an LLM can select a function from a database. It is whether the system can repeatedly convert a long repository task into a compact graph, reject dangerous near misses, bind the graph to exact compatible implementations, materialize it deterministically, pass hidden tests, and reduce total tokens and human correction after accounting for the cost of building and maintaining the registry.

The workbook provides the schema and experimental machinery to answer that question rather than assume the answer.

---

## Full source map

1. [DreamCoder](https://arxiv.org/abs/2006.08381) — Program synthesis; 2020–2023.
2. [LILO](https://arxiv.org/abs/2310.19791) — Program synthesis; 2023.
3. [Stitch](https://arxiv.org/abs/2211.16605) — Program synthesis; 2022.
4. [SyPet](https://dl.acm.org/doi/10.1145/3009837.3009851) — Program synthesis; 2017.
5. [APIphany](https://arxiv.org/abs/2203.16697) — Program synthesis; 2022.
6. [Counterexample-Guided Inductive Synthesis (CEGIS)](https://doi.org/10.1007/11817963_18) — Program synthesis; 2006+.
7. [SKETCH](https://people.csail.mit.edu/asolar/papers/sketch.pdf) — Program synthesis; 2008.
8. [Rosette](https://doi.org/10.1145/2666356.2594340) — Program synthesis; 2014.
9. [Synquid](https://doi.org/10.1145/2908080.2908093) — Program synthesis; 2016.
10. [SemGuS](https://www.semgus.org/) — Program synthesis; 2021.
11. [FlashFill](https://www.microsoft.com/en-us/research/publication/automating-string-processing-in-spreadsheets-using-input-output-examples/) — Program synthesis; 2011.
12. [Library Learning Doesn't](https://arxiv.org/abs/2410.20274) — Program synthesis; 2024.
13. [Bayesian Program Learning by Decompiling Amortized Knowledge](https://arxiv.org/abs/2306.07856) — Program synthesis; 2023–2024.
14. [E-graphs and equality saturation](https://arxiv.org/abs/2004.03082) — Program synthesis; 2009+.
15. [CodeSearchNet](https://arxiv.org/abs/1909.09436) — Code retrieval; 2019.
16. [CoIR](https://arxiv.org/abs/2407.02883) — Code retrieval; 2024.
17. [CodeXEmbed](https://arxiv.org/abs/2411.12644) — Code retrieval; 2025.
18. [CoRNStack](https://arxiv.org/abs/2410.01026) — Code retrieval; 2024.
19. [CoSQA+](https://arxiv.org/abs/2406.11589) — Code retrieval; 2024.
20. [CoQuIR](https://arxiv.org/abs/2506.11066) — Code retrieval; 2025.
21. [CodeBERT](https://arxiv.org/abs/2002.08155) — Code retrieval; 2020.
22. [GraphCodeBERT](https://arxiv.org/abs/2009.08366) — Code retrieval; 2020.
23. [UniXcoder](https://arxiv.org/abs/2203.03850) — Code retrieval; 2022.
24. [CodeT5+](https://arxiv.org/abs/2305.07922) — Code retrieval; 2023.
25. [CodeRetriever](https://arxiv.org/abs/2201.10866) — Code retrieval; 2022.
26. [CodeSage](https://arxiv.org/abs/2402.01935) — Code retrieval; 2024.
27. [Repository-level code search benchmarks](https://arxiv.org/abs/2303.12570) — Code retrieval; 2023+.
28. [BEIR](https://arxiv.org/abs/2104.08663) — Information retrieval; 2021.
29. [MTEB](https://arxiv.org/abs/2210.07316) — Information retrieval; 2022+.
30. [BGE-M3](https://arxiv.org/abs/2402.03216) — Information retrieval; 2024.
31. [SPLADE](https://arxiv.org/abs/2107.05720) — Information retrieval; 2021.
32. [ColBERT](https://arxiv.org/abs/2004.12832) — Information retrieval; 2020.
33. [ColBERTv2](https://arxiv.org/abs/2112.01488) — Information retrieval; 2021–2022.
34. [PLAID](https://arxiv.org/abs/2205.09707) — Information retrieval; 2022.
35. [Reciprocal Rank Fusion](https://doi.org/10.1145/1571941.1572114) — Information retrieval; 2009.
36. [Dense Passage Retrieval](https://arxiv.org/abs/2004.04906) — Information retrieval; 2020.
37. [Contriever](https://arxiv.org/abs/2112.09118) — Information retrieval; 2021.
38. [E5](https://arxiv.org/abs/2212.03533) — Information retrieval; 2022.
39. [HyDE](https://arxiv.org/abs/2212.10496) — Information retrieval; 2022.
40. [HNSW](https://arxiv.org/abs/1603.09320) — ANN indexing; 2016.
41. [Product Quantization](https://doi.org/10.1109/TPAMI.2010.57) — ANN indexing; 2011.
42. [Optimized Product Quantization](https://doi.org/10.1109/TPAMI.2013.240) — ANN indexing; 2013.
43. [DiskANN](https://papers.nips.cc/paper/2019/hash/09853c7fb1d3f8ee67a61b6bf4a7f8e6-Abstract.html) — ANN indexing; 2019.
44. [Filtered-DiskANN](https://arxiv.org/abs/2301.03765) — ANN indexing; 2023.
45. [ScaNN](https://arxiv.org/abs/1908.10396) — ANN indexing; 2020.
46. [SPANN](https://arxiv.org/abs/2111.08566) — ANN indexing; 2021.
47. [BigANN](https://big-ann-benchmarks.com/) — ANN indexing; 2021+.
48. [FAISS](https://arxiv.org/abs/1702.08734) — ANN indexing; 2017+.
49. [Vespa](https://docs.vespa.ai/en/) — ANN indexing; Current.
50. [Qdrant](https://qdrant.tech/documentation/) — ANN indexing; Current.
51. [Milvus](https://milvus.io/docs) — ANN indexing; Current.
52. [OpenSearch hybrid search](https://opensearch.org/docs/latest/vector-search/ai-search/hybrid-search/) — ANN indexing; Current.
53. [Toolformer](https://arxiv.org/abs/2302.04761) — Tool retrieval; 2023.
54. [ToolLLM / ToolBench](https://arxiv.org/abs/2307.16789) — Tool retrieval; 2023.
55. [Gorilla / APIBench](https://arxiv.org/abs/2305.15334) — Tool retrieval; 2023.
56. [ToolkenGPT](https://arxiv.org/abs/2305.11554) — Tool retrieval; 2023.
57. [AnyTool](https://arxiv.org/abs/2402.04253) — Tool retrieval; 2024.
58. [ToolNet](https://arxiv.org/abs/2405.04255) — Tool retrieval; 2024.
59. [StableToolBench](https://arxiv.org/abs/2403.07714) — Tool retrieval; 2024.
60. [LiveMCPBench](https://arxiv.org/abs/2508.01780) — Tool retrieval; 2025.
61. [Model Context Protocol](https://modelcontextprotocol.io/specification/) — Tool retrieval; 2024+.
62. [Software Heritage](https://www.softwareheritage.org/) — Code corpus; 2016+.
63. [The Stack v2](https://huggingface.co/datasets/bigcode/the-stack-v2) — Code corpus; 2024.
64. [Cracks in The Stack](https://arxiv.org/abs/2412.12274) — Code corpus; 2024.
65. [Zoekt](https://github.com/sourcegraph/zoekt) — Code indexing; Current.
66. [Kythe](https://kythe.io/) — Code indexing; Current.
67. [Language Server Protocol](https://microsoft.github.io/language-server-protocol/) — Code indexing; Current.
68. [SCIP](https://github.com/sourcegraph/scip) — Code indexing; Current.
69. [RepoFormer](https://arxiv.org/abs/2403.10059) — Token efficiency; 2024.
70. [SWE-Effi](https://arxiv.org/abs/2509.09853) — Token efficiency; 2025.
71. [SWE-Replay](https://arxiv.org/abs/2601.22129) — Token efficiency; 2025.
72. [AgentDiet](https://arxiv.org/abs/2509.23586) — Token efficiency; 2025.
73. [SWE-Pruner](https://arxiv.org/abs/2506.06396) — Token efficiency; 2025.
74. [EET](https://arxiv.org/abs/2505.18382) — Token efficiency; 2025.
75. [ChainSWE](https://arxiv.org/abs/2504.13343) — Token efficiency; 2025.
76. [SWE-bench](https://arxiv.org/abs/2310.06770) — Token efficiency; 2023+.
77. [SWE-bench Verified](https://openai.com/index/introducing-swe-bench-verified/) — Token efficiency; 2024+.
78. [RepoBench](https://arxiv.org/abs/2306.03091) — Token efficiency; 2023.
79. [CrossCodeEval](https://arxiv.org/abs/2310.11248) — Token efficiency; 2023.
80. [SWE-fficiency](https://arxiv.org/abs/2505.08865) — Token efficiency; 2025.
81. [RefactorBench](https://openreview.net/forum?id=NiNIthntx7) — Token efficiency; 2025.
82. [How Do AI Agents Spend Your Money?](https://arxiv.org/abs/2505.19444) — Token efficiency; 2025.
83. [WebAssembly Component Model and WIT](https://component-model.bytecodealliance.org/) — Standards & trust; Current.
84. [OCI Distribution Specification](https://github.com/opencontainers/distribution-spec) — Standards & trust; Current.
85. [SLSA provenance](https://slsa.dev/spec/) — Standards & trust; Current.
86. [Sigstore](https://docs.sigstore.dev/) — Standards & trust; Current.
87. [in-toto](https://in-toto.io/) — Standards & trust; Current.
88. [SPDX](https://spdx.dev/) — Standards & trust; Current.
89. [CycloneDX](https://cyclonedx.org/) — Standards & trust; Current.
90. [CUE](https://cuelang.org/docs/) — Standards & trust; Current.
91. [Open Policy Agent / Rego](https://www.openpolicyagent.org/docs/latest/) — Standards & trust; Current.
92. [Bazel remote caching model](https://bazel.build/remote/caching) — Standards & trust; Current.
